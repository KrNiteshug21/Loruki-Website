console.log('Dad Jokes Starter');
